# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dumpgenerator', 'dumpgenerator.util']

package_data = \
{'': ['*']}

install_requires = \
['PyMySQL>=1.0.2,<2.0.0',
 'argparse>=1.4.0,<2.0.0',
 'internetarchive>=2.1.0,<3.0.0',
 'lxml>=4.6.3,<5.0.0',
 'mwclient>=0.10.1,<0.11.0',
 'pymysql',
 'pywikibot>=6.6.1,<7.0.0',
 'requests>=2.26.0,<3.0.0',
 'urllib3>=1.26.7,<2.0.0',
 'wikitools3>=3.0.0,<4.0.0']

entry_points = \
{'console_scripts': ['dumpgenerator = wikiteam3.dumpgenerator:main']}

setup_kwargs = {
    'name': 'wikiteam3',
    'version': '3.0.0',
    'description': 'Tools for downloading and preserving wikis. We archive wikis, from Wikipedia to tiniest wikis. As of 2020, WikiTeam has preserved more than 250,000 wikis.',
    'long_description': '# WikiTeam\n### We archive wikis, from Wikipedia to tiniest wikis\n\n**WikiTeam software is a set of tools for archiving wikis.** They work on MediaWiki wikis, but we want to expand to other wiki engines. As of 2020, WikiTeam has preserved more than [250,000 wikis](https://github.com/WikiTeam/wikiteam/wiki/Available-Backups), several wikifarms, regular Wikipedia dumps and [34 TB of Wikimedia Commons images](https://archive.org/details/wikimediacommons).\n\nThere are [thousands](http://wikiindex.org) of [wikis](https://wikiapiary.com) in the Internet. Every day some of them are no longer publicly available and, due to lack of backups, lost forever. Millions of people download tons of media files (movies, music, books, etc) from the Internet, serving as a kind of distributed backup. Wikis, most of them under free licenses, disappear from time to time because nobody grabbed a copy of them. That is a shame that we would like to solve.\n\n**WikiTeam** is the [Archive Team](http://www.archiveteam.org) ([GitHub](https://github.com/ArchiveTeam)) subcommittee on wikis. It was founded and originally developed by [Emilio J. Rodríguez-Posada](https://github.com/emijrp), a Wikipedia veteran editor and amateur archivist. Many people have helped by sending suggestions, [reporting bugs](https://github.com/WikiTeam/wikiteam/issues), writing [documentation](https://github.com/WikiTeam/wikiteam/wiki), providing help in the [mailing list](http://groups.google.com/group/wikiteam-discuss) and making [wiki backups](https://github.com/WikiTeam/wikiteam/wiki/Available-Backups). Thanks to all, especially to: [Federico Leva](https://github.com/nemobis), [Alex Buie](https://github.com/ab2525), [Scott Boyd](http://www.sdboyd56.com), [Hydriz](https://github.com/Hydriz), Platonides, Ian McEwen, [Mike Dupont](https://github.com/h4ck3rm1k3), [balr0g](https://github.com/balr0g) and [PiRSquared17](https://github.com/PiRSquared17).\n\n<table border=0 cellpadding=5px>\n<tr><td>\n<a href="https://github.com/WikiTeam/wikiteam/wiki/Tutorial"><img src="https://upload.wikimedia.org/wikipedia/commons/f/f3/Nuvola_apps_Wild.png" width=100px alt="Documentation" title="Documentation"/></a>\n</td><td>\n<a href="https://raw.githubusercontent.com/WikiTeam/wikiteam/master/dumpgenerator.py"><img src="http://upload.wikimedia.org/wikipedia/commons/2/2a/Nuvola_apps_kservices.png" width=100px alt="Source code" title="Source code"/></a>\n</td><td>\n<a href="https://github.com/WikiTeam/wikiteam/wiki/Available-Backups"><img src="https://upload.wikimedia.org/wikipedia/commons/3/37/Nuvola_devices_3floppy_mount.png" width=100px alt="Download available backups" title="Download available backups"/></a>\n</td><td>\n<a href="https://groups.google.com/group/wikiteam-discuss"><img src="https://upload.wikimedia.org/wikipedia/commons/0/0f/Nuvola_apps_kuser.png" width=100px alt="Community" title="Community"/></a>\n</td><td>\n<a href="https://twitter.com/_WikiTeam"><img src="https://upload.wikimedia.org/wikipedia/commons/e/eb/Twitter_logo_initial.png" width=90px alt="Follow us on Twitter" title="Follow us on Twitter"/></a>\n</td></tr>\n</table>\n\n## Quick guide\n\nThis is a very quick guide for the most used features of WikiTeam tools. For further information, read the [tutorial](https://github.com/WikiTeam/wikiteam/wiki/Tutorial) and the rest of the [documentation](https://github.com/WikiTeam/wikiteam/wiki). You can also ask in the [mailing list](http://groups.google.com/group/wikiteam-discuss).\n\nThese instructions assume you will run WikiTeam from a cloned or downloaded copy of this repository. WikiTeam3 may eventually be available from PyPI, in which case the instructions will vary.\n\n### Requirements\n\nRequires <a href="https://www.python.org/downloads/release/python-380/">Python 3.8</a> or later (less than 4.0).\n\nConfirm you satisfy the requirements:\n\n`pip install poetry`\n\nor, if you don\'t have enough permissions for the above,\n\n`pip install --user poetry`\n\nOnce `poetry` is installed, in the `wikiteam3` directory, run:\n\n`poetry install`\n\n### Download any wiki\n\nTo download any wiki, in the `wikiteam3` directory, use one of the following options:\n\n`poetry run python dumpgenerator.py http://wiki.domain.org --xml --images` (complete XML histories and images)\n\nIf the script can\'t find itself the API and/or index.php paths, then you can provide them:\n\n`poetry run python dumpgenerator.py --api=http://wiki.domain.org/w/api.php --xml --images`\n\n`poetry run python dumpgenerator.py --api=http://wiki.domain.org/w/api.php --index=http://wiki.domain.org/w/index.php --xml --images`\n\nIf you only want the XML histories, just use `--xml`. For only the images, just `--images`. For only the current version of every page, `--xml --curonly`.\n\nYou can resume an aborted download:\n\n`poetry run python dumpgenerator.py --api=http://wiki.domain.org/w/api.php --xml --images --resume --path=/path/to/incomplete-dump`\n\nSee more options:\n\n`poetry run python dumpgenerator.py --help`\n\n### Download Wikimedia dumps\n\nTo download [Wikimedia XML dumps](http://dumps.wikimedia.org/backup-index.html) (Wikipedia, Wikibooks, Wikinews, etc) you can run:\n\n`poetry run python wikipediadownloader.py` (download all projects)\n\nSee more options:\n\n`poetry run python wikipediadownloader.py --help`\n\n### Download Wikimedia Commons images\n\nThere is a script for this, but we have [uploaded the tarballs](https://archive.org/details/wikimediacommons) to Internet Archive, so it\'s more useful to reseed their torrents than to re-generate old ones with the script.\n\n## Developers\n\n[![Build Status](https://travis-ci.org/WikiTeam/wikiteam.svg)](https://travis-ci.org/WikiTeam/wikiteam)\n\n> **Note:** Tests are not currently working. These instructions will be updated ASAP.\n\nYou can run tests easily by using the [tox](https://pypi.python.org/pypi/tox) command.  It is probably already present in your operating system, you would need version 1.6.  If it is not, you can download it from pypi with: `pip install tox`.\n\nExample usage:\n\n    $ tox\n    py27 runtests: commands[0] | nosetests --nocapture --nologcapture\n    Checking http://wiki.annotation.jp/api.php\n    Trying to parse かずさアノテーション - ソーシャル・ゲノム・アノテーション.jpg from API\n    Retrieving image filenames\n    .    Found 266 images\n    .\n    -------------------------------------------\n    Ran 1 test in 2.253s\n\n    OK\n    _________________ summary _________________\n      py27: commands succeeded\n      congratulations :)\n    $\n',
    'author': 'WikiTeam Contributors',
    'author_email': 'https://github.com/WikiTeam/wikiteam/graphs/contributors',
    'maintainer': 'Federico Leva',
    'maintainer_email': 'https://github.com/nemobis',
    'url': 'https://wiki.archiveteam.org/index.php/WikiTeam',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
