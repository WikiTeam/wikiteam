# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['dumpgenerator']

package_data = \
{'': ['*']}

install_requires = \
['PyMySQL>=1.0.2,<2.0.0',
 'argparse>=1.4.0,<2.0.0',
 'file_read_backwards>=2.0.0,<3.0.0',
 'internetarchive>=2.1.0,<3.0.0',
 'lxml>=4.9.1,<5.0.0',
 'mwclient>=0.10.1,<0.11.0',
 'pre-commit-poetry-export>=0.1.2,<0.2.0',
 'pymysql',
 'pywikibot>=6.6.1,<7.0.0',
 'requests>=2.26.0,<3.0.0',
 'urllib3>=1.26.7,<2.0.0',
 'wikitools3>=3.0.0,<4.0.0']

entry_points = \
{'console_scripts': ['dumpgenerator = wikiteam3.dumpgenerator:main']}

setup_kwargs = {
    'name': 'wikiteam3',
    'version': '3.0.0',
    'description': 'Tools for downloading and preserving wikis. We archive wikis, from Wikipedia to tiniest wikis. As of 2020, WikiTeam has preserved more than 250,000 wikis.',
    'long_description': "# `wikiteam3`\n\n***We archive wikis, from Wikipedia to the tiniest wikis***\n\n`wikiteam3` is an ongoing project to port the legacy [`wikiteam`](https://github.com/WikiTeam/wikiteam) toolset to Python 3 and PyPI to make it more accessible for today's archivers.\n\nMost of the focus has been on the core `dumpgenerator` tool, but Python 3 versions of the other `wikiteam` tools may be added over time.\n\n## `wikiteam3` Toolset\n\n`wikiteam3` is a set of tools for archiving wikis. The tools work on MediaWiki wikis, but the team hopes to expand to other wiki engines. As of 2020, WikiTeam has preserved more than [250,000 wikis](https://github.com/WikiTeam/wikiteam/wiki/Available-Backups), several wikifarms, regular Wikipedia dumps and [34 TB of Wikimedia Commons images](https://archive.org/details/wikimediacommons).\n\nThe main general-purpose module of `wikiteam3` is `dumpgenerator`, which can download XML dumps of MediaWiki sites that can then be parsed or redeployed elsewhere.\n\n## Using `dumpgenerator`\n\nThe Python 3 port of the `dumpgenerator` module of `wikiteam3` is largely functional and can be installed from a downloaded or cloned copy of this repository.\n\n> `wikiteam3` requires [Python 3.8](https://www.python.org/downloads/release/python-380/) or later (less than 4.0), but you may be able to get it run with earlier versions of Python 3.\n\nThere are two versions of these instructions:\n\n* If you just want to use a version that mostly works\n* If you want to follow my progress and help me test my latest commit\n\n> If you run into a problem with the version that mostly works, you can [open an Issue](https://github.com/elsiehupp/wikiteam3/issues/new/choose). Be sure to include the following:\n>\n> 1. The operating system you're using\n> 2. What command you ran that didn't work\n> 3. What output was printed to your terminal\n\n### If you just want to use a version that mostly works\n\n#### 1. Download and install\n\nIn whatever folder you use for cloned repositories:\n\n```bash\n$ git clone https://github.com/elsiehupp/wikiteam3.git\n$ cd wikiteam3\n$ git checkout --track origin/python3\n$ pip install --force-reinstall dist/*.whl\n```\n\n#### 2. Run `dumpgenerator` for whatever purpose you need\n\n```bash\n$ dumpgenerator [args]\n```\n\n#### 3. To uninstall the package and delete the cloned repository when you're done\n\n```shell\n$ pip uninstall wikiteam3\n$ rm -r [cloned_wikiteam3_folder]\n```\n\nIf you'd like to manually install `wikiteam3` from a cloned or downloaded copy of this repository, run the following commands from the downloaded base directory:\n\n```bash\n$ curl -sSL https://install.python-poetry.org | python3 -\n$ poetry install\n$ poetry build\n$ pip install --force-reinstall dist/*.whl\n```\n\nIn either case, to uninstall `wikiteam3` run this command (from any local directory):\n\n```bash\npip uninstall wikiteam3\n```\n\n### If you want to follow my progress and help me test my latest commit\n\n> **Note:** this branch may not actually work at any given time!\n\n#### 1. Install [Python Poetry](https://python-poetry.org/)\n\n```bash\n$ curl -sSL https://raw.githubusercontent.com/python-poetry/poetry/master/get-poetry.py | python -\n```\n\n> **Note:** if you get an SSL error, you may need to follow the instructions [here](https://github.com/python-poetry/poetry/issues/5117).\n\n#### 2. Clone the repository and switch to the `prepare-for-publication` branch\n\n```bash\n$ git clone git@github.com:elsiehupp/wikiteam3.git\n```\n\nor\n\n```bash\n$ git clone https://github.com/elsiehupp/wikiteam3.git\n```\n\nthen:\n\n```bash\n$ cd wikiteam3\n$ git checkout --track origin/prepare-for-publication\n```\n\n#### 3. Build and install\n\n> **Note:** Re-run the following steps each time to reinstall each time the `wikiteam3` branch is updated.\n\n```shell\n$ git pull\n$ poetry update && poetry install && poetry build\n$ pip install --force-reinstall dist/*.whl\n```\n\n#### 4. Then, from anywhere, you should be able to run\n\n```shell\n$ dumpgenerator [args]\n```\n\n> To run the test suite, run:\n>\n> ```bash\n> $ test-dumpgenerator\n> ```\n\n#### 5. To uninstall the package and delete the cloned repository when you're done\n\n```shell\n$ pip uninstall wikiteam3\n$ rm -r [cloned_wikiteam3_folder]\n```\n\n### Using `dumpgenerator`\n\nAfter installing `wikiteam3` using `pip` you should be able to use the `dumpgenerator` command from any local directory.\n\nFor basic usage, you can run `dumpgenerator` in the directory where you'd like the download to be.\n\nFor a brief summary of the `dumpgenerator` command-line options:\n\n```bash\n$ dumpgenerator --help\n```\n\nSeveral examples follow:\n\n#### To download a wiki with omplete XML histories and images:\n\n```bash\n$ dumpgenerator http://wiki.domain.org --xml --images\n```\n\n#### If the script can't find itself the `api.php` and/or `index.php` paths, then you can provide them:\n\n```bash\n$ dumpgenerator --api http://wiki.domain.org/w/api.php --xml --images\n```\n\n\n```bash\n$ dumpgenerator --api http://wiki.domain.org/w/api.php --index http://wiki.domain.org/w/index.php --xml --images\n```\n\nIf you only want the XML histories, just use `--xml`. For only the images, just `--images`. For only the current version of every page, `--xml --current`.\n\n#### You can resume an aborted download:\n\n```bash\n$ dumpgenerator --api http://wiki.domain.org/w/api.php --xml --images --resume --path=/path/to/incomplete-dump\n```\n\n`dumpgenerator` will also ask you if you want to resume if it detects an aborted download as it is running.\n\n## WikiTeam Team\n\n**WikiTeam** is the [Archive Team](http://www.archiveteam.org) [[GitHub](https://github.com/ArchiveTeam)] subcommittee on wikis.\n\nIt was founded and originally developed by [Emilio J. Rodríguez-Posada](https://github.com/emijrp), a Wikipedia veteran editor and amateur archivist. Thanks to people who have helped, especially to: [Federico Leva](https://github.com/nemobis), [Alex Buie](https://github.com/ab2525), [Scott Boyd](http://www.sdboyd56.com), [Hydriz](https://github.com/Hydriz), Platonides, Ian McEwen, [Mike Dupont](https://github.com/h4ck3rm1k3), [balr0g](https://github.com/balr0g) and [PiRSquared17](https://github.com/PiRSquared17).\n\nThe Python 3 initiative is currently being led by [Elsie Hupp](https://github.com/elsiehupp), with contributions from [Victor Gambier](https://github.com/vgambier) and [Thomas Karcher](https://github.com/t-karcher).\n",
    'author': 'WikiTeam Contributors',
    'author_email': 'https://github.com/WikiTeam/wikiteam/graphs/contributors',
    'maintainer': 'Federico Leva',
    'maintainer_email': 'https://github.com/nemobis',
    'url': 'https://wiki.archiveteam.org/index.php/WikiTeam',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
