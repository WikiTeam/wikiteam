import datetime

from .version import getVersion


def welcome():
    message = ""
    """Opening message"""
    message += "#" * 73
    message += """
# Welcome to DumpGenerator %s by WikiTeam (GPL v3)                   #
# More info at: https://github.com/WikiTeam/wikiteam                    #""" % (
        getVersion()
    )
    message += "\n"
    message += "#" * 73
    message += "\n"
    message += ""
    message += "\n"
    message += "#" * 73
    message += "\n"
    message += (
        "# Copyright (C) 2011-%d WikiTeam developers                           #\n"
        % (datetime.datetime.now().year)
    )
    message += """
# This program is free software: you can redistribute it and/or modify  #
# it under the terms of the GNU General Public License as published by  #
# the Free Software Foundation, either version 3 of the License, or     #
# (at your option) any later version.                                   #
#                                                                       #
# This program is distributed in the hope that it will be useful,       #
# but WITHOUT ANY WARRANTY; without even the implied warranty of        #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         #
# GNU General Public License for more details.                          #
#                                                                       #
# You should have received a copy of the GNU General Public License     #
# along with this program.  If not, see <http://www.gnu.org/licenses/>. #"""
    message += "\n"
    message += "#" * 73
    message += "\n"
    message += ""

    return message


def bye():
    """Closing message"""
    print("")
    print("---> Congratulations! Your dump is complete <---")
    print("")
    print("If you found any bug, report a new issue here:")
    print("  https://github.com/WikiTeam/wikiteam/issues")
    print("")
    print("If this is a public wiki, please, consider publishing this dump.")
    print("Do it yourself as explained in:")
    print("  https://github.com/WikiTeam/wikiteam/wiki/Tutorial#Publishing_the_dump")
    print("Or contact us at:")
    print("  https://github.com/WikiTeam/wikiteam")
    print("")
    print("Good luck! Bye!")
    print("")
