__VERSION__ = "0.4.0-alpha"  # major, minor, micro: semver.org


def getVersion():
    return __VERSION__
